library ieee; use ieee.std_logic_1164.all;
entity fa is
  port(
    a, b, cin: in std_ulogic;
    cout, s:   out std_ulogic
  );
end;

architecture rtl of fa is
begin
  s <= a xor b xor cin;
  cout <= (a and b) or (cin and (a xor b));
end;

library ieee; use ieee.std_logic_1164.all;
entity adder is
  generic(
    BW: positive := 8
  );
  port(
    a, b:     in std_ulogic_vector(BW-1 downto 0);
    cin:      in std_ulogic;
    cout:     out std_ulogic;
    overflow: out std_ulogic;
    s:        out std_ulogic_vector(BW-1 downto 0)
  );
end;

architecture rtl of adder is
  signal c : std_ulogic_vector(BW downto 0);
begin
  c(0) <= cin;

  carry_ripple_adder : for i in 0 to BW-1 generate
    fa_i: entity work.fa(rtl)
     port map(
        a    => a(i),
        b    => b(i),
        cin  => c(i),
        cout => c(i+1),
        s    => s(i)
    );
  end generate;

  cout <= c(BW);
  overflow <= c(BW-1);
end;

library ieee; use ieee.std_logic_1164.all;
entity add_sub is
  generic(
    BW: positive := 8
  );
  port(
    a, b:     in std_ulogic_vector(BW-1 downto 0);
    sub:      in std_ulogic;
    result:   out std_ulogic_vector(BW-1 downto 0);
    overflow: out std_ulogic
  );
end;

architecture rtl of add_sub is
  signal b2k : std_ulogic_vector(BW-1 downto 0) := (others => '0');
  signal c2k : std_ulogic := '0';
  signal cout : std_ulogic := '0';
begin
  b2k <= b xor sub;
  overflow <= c2k xor cout;

  adder : entity work.adder(rtl)
  port map (
    a        => a,
    b        => b2k,
    cin      => sub, -- +1 for 2s complement is added here
    cout     => cout,
    overflow => c2k,
    s        => result
  );
end;
